package pl.krejzolekpro.funnyescape;

import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import pl.krejzolekpro.funnyescape.commands.EscapeCommand;
import pl.krejzolekpro.funnyescape.data.Config;
import pl.krejzolekpro.funnyescape.listeners.MoveListener;

public class FunnyEscape extends JavaPlugin{

	public static FunnyEscape plugin;
	
	public void onEnable(){
		plugin = this;
		plugin.saveDefaultConfig();
		PluginManager pm = getServer().getPluginManager();
		pm.registerEvents(new MoveListener(), plugin);
		getCommand("escape").setExecutor(new EscapeCommand());
		Config.load();
		if(pm.getPlugin("FunnyGuilds") != null){
            System.out.println("[FunnyEscape] Plugin FunnyGuilds zostal znaleziony. Plugin zostaje wlaczony.");
		} else {
			System.out.println("[FunnyEscape] Plugin FunnyGuilds nie zostal znaleziony. Plugin zostaje wylaczony.");
            pm.disablePlugin(this);
		}
	}
	
	public static FunnyEscape getPlugin(){
		return plugin;
	}
}
