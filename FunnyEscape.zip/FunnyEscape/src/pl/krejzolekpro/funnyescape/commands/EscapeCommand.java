package pl.krejzolekpro.funnyescape.commands;

import java.util.HashMap;
import java.util.Map;

import net.dzikoysk.funnyguilds.basic.Guild;
import net.dzikoysk.funnyguilds.basic.Region;
import net.dzikoysk.funnyguilds.basic.User;
import net.dzikoysk.funnyguilds.basic.util.RegionUtils;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import pl.krejzolekpro.funnyescape.FunnyEscape;
import pl.krejzolekpro.funnyescape.data.Config;
import pl.krejzolekpro.funnyescape.utils  .StringUtil;

public class EscapeCommand implements CommandExecutor{
	
	public static Map<String, BukkitTask> delay = new HashMap<String, BukkitTask>();
	private Region region;

	@Override
	public boolean onCommand(CommandSender cs, Command cmd, String lebel, String[] args) {
		if(cmd.getName().equalsIgnoreCase("escape")){
			if(cs instanceof Player){
				final Player p = ((Player) cs).getPlayer();
				final Location loc = p.getLocation();
				region = RegionUtils.getAt(loc);
				final User user = User.get(p);
				if(user.hasGuild()){
					final Guild g = user.getGuild();
					if(region != null){
						if(!(region.getName().equals(g.getName()))){
							BukkitTask bt = Bukkit.getScheduler().runTaskLater(FunnyEscape.getPlugin(), new Runnable(){
								public void run(){
									if(delay.containsKey(p.getName())){
										p.sendMessage(StringUtil.fixColor(Config.ESCAPE_MESSAGE_SUCCESS));
										((BukkitTask)delay.remove(p.getName())).cancel();
										if(g != null){
											p.teleport(g.getHome());
											return;
										}
									}
								}
							}, Config.ESCAPE_TIME*20);
							String m = Config.ESCAPE_MESSAGE_PLAYER;
							m = m.replace("{TIME}", Config.ESCAPE_TIME + "");
							delay.put(p.getName(), bt);
							p.sendMessage(StringUtil.fixColor(m));
							Guild guild = region.getGuild();
							String mess = Config.ESCAPE_MESSAGE_MEMBER;
							mess = mess.replace("{PLAYER}", p.getName());
							mess = mess.replace("{X}", loc.getX() + "");
							mess = mess.replace("{Z}", loc.getZ() + "");
							mess = mess.replace("{Y}", loc.getY() + "");
							mess = mess.replace("{TME}", Config.ESCAPE_TIME + "");
							for(User pl : guild.getMembers()){
								pl.getPlayer().sendMessage(StringUtil.fixColor(mess));
							}
						} else {
							p.sendMessage(StringUtil.fixColor(Config.ESCAPE_REGION_IS_YOUR));
						}
						
					} else {
						p.sendMessage(StringUtil.fixColor(Config.ESCAPE_REGION_IS_EMPTY));
					}
				} else {
					p.sendMessage(StringUtil.fixColor(Config.ESCAPE_PLAYER_HASNOT_GUILD));
				}
			}
		}
		return false;
	}

	
}
