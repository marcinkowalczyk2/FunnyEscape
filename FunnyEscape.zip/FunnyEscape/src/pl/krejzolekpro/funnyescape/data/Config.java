package pl.krejzolekpro.funnyescape.data;

import org.bukkit.configuration.file.FileConfiguration;

import pl.krejzolekpro.funnyescape.FunnyEscape;
import pl.krejzolekpro.funnyescape.utils.StringUtil;

public class Config {
	
	public static int ESCAPE_TIME = 60;
	public static String ESCAPE_MESSAGE_PLAYER = StringUtil.fixColor("&6Ucieczka nastapi za {TIME} sek.");
	public static String ESCAPE_MESSAGE_MEMBER = StringUtil.fixColor("&6Gracz {PLAYER} probuje uciec z terenu Twojej gildii. Jego koordynata X: {X}.");
	public static String ESCAPE_MESSAGE_FAILED = StringUtil.fixColor("&cUcieczka zostala przerwana.");
	public static String ESCAPE_MESSAGE_SUCCESS = StringUtil.fixColor("&aUcieczka powiodla sie.");
	public static String ESCAPE_REGION_IS_YOUR = StringUtil.fixColor("&cNie mozesz uciec ze swojej gildii.");
	public static String ESCAPE_REGION_IS_EMPTY = StringUtil.fixColor("&cNie znajdujesz sie na terenie zadnej gildii.");
	public static String ESCAPE_PLAYER_HASNOT_GUILD = StringUtil.fixColor("&cAby uciec z terenu, musisz posiadac gildie.");
	
	public static void load(){
		FileConfiguration yaml = FunnyEscape.getPlugin().getConfig();
		try{
			ESCAPE_TIME = yaml.getInt("ESCAPE_TIME");
		} catch(NumberFormatException e){
			e.printStackTrace();
		}
		
		if(yaml.getString("ESCAPE_MESSAGE_PLAYER") != null){
			ESCAPE_MESSAGE_PLAYER = yaml.getString("ESCAPE_MESSAGE_PLAYER");
		}
		
		if(yaml.getString("ESCAPE_MESSAGE_MEMBER") != null){
			ESCAPE_MESSAGE_MEMBER = yaml.getString("ESCAPE_MESSAGE_MEMBER");
		}
		
		if(yaml.getString("ESCAPE_MESSAGE_FAILED") != null){
			ESCAPE_MESSAGE_FAILED = yaml.getString("ESCAPE_MESSAGE_FAILED");
		}
		
		if(yaml.getString("ESCAPE_MESSAGE_SUCCESS") != null){
			ESCAPE_MESSAGE_SUCCESS = yaml.getString("ESCAPE_MESSAGE_SUCCESS");
		}
	}
}
