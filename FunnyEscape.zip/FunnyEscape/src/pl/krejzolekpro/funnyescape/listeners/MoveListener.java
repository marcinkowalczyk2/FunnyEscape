package pl.krejzolekpro.funnyescape.listeners;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

import pl.krejzolekpro.funnyescape.commands.EscapeCommand;
import pl.krejzolekpro.funnyescape.data.Config;
import pl.krejzolekpro.funnyescape.utils.StringUtil;

public class MoveListener implements Listener{

	@EventHandler
	public void onMove(PlayerMoveEvent e){
		if(EscapeCommand.delay.containsKey(e.getPlayer().getName())){
			EscapeCommand.delay.remove(e.getPlayer().getName()).cancel();
			e.getPlayer().sendMessage(StringUtil.fixColor(Config.ESCAPE_MESSAGE_FAILED));
		}
	}
}
