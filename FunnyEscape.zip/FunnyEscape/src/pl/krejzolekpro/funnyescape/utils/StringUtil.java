package pl.krejzolekpro.funnyescape.utils;

import org.bukkit.ChatColor;

public class StringUtil {
	
	public static String fixColor(String s){
		return ChatColor.translateAlternateColorCodes('&', s);
	}

}
